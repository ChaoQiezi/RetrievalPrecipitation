# @Author   : ChaoQiezi
# @Time     : 2024/3/3  12:00
# @Email    : chaoqiezi.one@qq.com

"""
This script is used to 用于将nc文件转为tiff文件
"""
import glob
from typing import Union

import numpy as np
from osgeo import gdal, osr
import netCDF4 as nc


def img_warp(src_img: np.ndarray, out_path: str, transform: list, out_res: float,
             nodata: Union[int, float] = None, resample: str = 'nearest') -> None:
    """
    该函数用于对正弦投影下的栅格矩阵进行重投影(GLT校正), 得到WGS84坐标系下的栅格矩阵并输出为TIFF文件
    :param src_img: 待重投影的栅格矩阵
    :param out_path: 输出路径
    :param transform: 仿射变换参数([x_min, x_res, 0, y_max, 0, -y_res], 旋转参数为0是常规选项)
    :param out_res: 输出的分辨率(栅格方形)
    :param nodata: 设置为NoData的数值
    :param out_type: 输出的数据类型
    :param resample: 重采样方法(默认是最近邻, ['nearest', 'bilinear', 'cubic'])
    :param src_proj4: 表达源数据集(src_img)的坐标系参数(以proj4字符串形式)
    :return: None
    """

    # 输出数据类型
    if np.issubdtype(src_img.dtype, np.integer):
        out_type = gdal.GDT_Int32
    elif np.issubdtype(src_img.dtype, np.floating):
        out_type = gdal.GDT_Float32
    else:
        raise ValueError("当前待校正数组类型为不支持的数据类型")
    resamples = {'nearest': gdal.GRA_NearestNeighbour, 'bilinear': gdal.GRA_Bilinear, 'cubic': gdal.GRA_Cubic}
    # 原始数据集创建(正弦投影)
    driver = gdal.GetDriverByName('MEM')  # 在内存中临时创建
    src_ds = driver.Create("", src_img.shape[1], src_img.shape[0], 1, out_type)  # 注意: 先传列数再传行数, 1表示单波段
    srs = osr.SpatialReference()
    # srs.ImportFromProj4(src_proj4)
    srs.ImportFromEPSG(4326)
    """
    对于src_proj4, 依据元数据StructMetadata.0知:
        Projection=GCTP_SNSOID; ProjParams=(6371007.181000,0,0,0,0,0,0,0,0,0,0,0,0)
    或数据集属性(MODIS_Grid_8Day_1km_LST/Data_Fields/Projection)知:
        :grid_mapping_name = "sinusoidal";
        :longitude_of_central_meridian = 0.0; // double
        :earth_radius = 6371007.181; // double
    """
    src_ds.SetProjection(srs.ExportToWkt())  # 设置投影信息
    src_ds.SetGeoTransform(transform)  # 设置仿射参数
    src_ds.GetRasterBand(1).WriteArray(src_img)  # 写入数据
    src_ds.GetRasterBand(1).SetNoDataValue(nodata)
    # 重投影信息(WGS84)
    dst_srs = osr.SpatialReference()
    dst_srs.ImportFromEPSG(4326)
    # 重投影
    dst_ds = gdal.Warp(out_path, src_ds, dstSRS=dst_srs, xRes=out_res, yRes=out_res, dstNodata=nodata,
                       outputType=out_type, multithread=True, format='GTiff', resampleAlg=resamples[resample])
    if dst_ds:  # 释放缓存和资源
        dst_ds.FlushCache()
        src_ds, dst_ds = None, None



# 准备
nc_path1 = 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_PM2.5_Y1K_2013_V4.nc'
nc_path2 = 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_PM2.5_Y1K_2022_V4.nc'
nc_path3 = 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_SO2_Y10K_2013_V1(10km).nc'
nc_path4 = 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_SO2_Y1K_2022_V2(1km).nc'
nc_paths = glob.glob('I:\\ObjectRS\\NC2TIFF\\Data\\*.nc')
f = nc.Dataset(nc_path1, mode='r')
lat, lon = f.variables['lat'][:], f.variables['lon'][:]
pm25 = np.array(f.variables['PM2.5'])
f.close()
lon_min = min(lon)
lon_max = max(lon)
lat_min = min(lat)
lat_max = max(lat)
lon_res = (lon_max - lon_min) / len(lon)
lat_res = (lat_max - lat_min) / len(lat)
out_res = (lon_res + lat_res) / 2.0
transform = [lon_min, lon_res, 0, lat_max, 0, -lat_res]  # 仿射变换参数
img_warp(pm25, 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_PM2.5_Y1K_2013_V4.tiff', transform, out_res=out_res, nodata=65535)


f = nc.Dataset(nc_path2, mode='r')
lat, lon = f.variables['lat'][:], f.variables['lon'][:]
pm25 = np.array(f.variables['PM2.5'])
f.close()
lon_min = min(lon)
lon_max = max(lon)
lat_min = min(lat)
lat_max = max(lat)
lon_res = (lon_max - lon_min) / len(lon)
lat_res = (lat_max - lat_min) / len(lat)
out_res = (lon_res + lat_res) / 2.0
transform = [lon_min, lon_res, 0, lat_max, 0, -lat_res]  # 仿射变换参数
img_warp(pm25, 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_PM2.5_Y1K_2022_V4.tiff', transform, out_res=out_res, nodata=65535)


f = nc.Dataset(nc_path3, mode='r')
lat, lon = f.variables['lat'][:], f.variables['lon'][:]
pm25 = np.array(f.variables['SO2'])
f.close()
lon_min = min(lon)
lon_max = max(lon)
lat_min = min(lat)
lat_max = max(lat)
lon_res = (lon_max - lon_min) / len(lon)
lat_res = (lat_max - lat_min) / len(lat)
out_res = (lon_res + lat_res) / 2.0
transform = [lon_min, lon_res, 0, lat_max, 0, -lat_res]  # 仿射变换参数
img_warp(pm25, 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_SO2_Y10K_2013_V1(10km).tiff', transform, out_res=out_res, nodata=65535)


f = nc.Dataset(nc_path4, mode='r')
lat, lon = f.variables['lat'][:], f.variables['lon'][:]
pm25 = np.array(f.variables['SO2'])
f.close()
lon_min = min(lon)
lon_max = max(lon)
lat_min = min(lat)
lat_max = max(lat)
lon_res = (lon_max - lon_min) / len(lon)
lat_res = (lat_max - lat_min) / len(lat)
out_res = (lon_res + lat_res) / 2.0
transform = [lon_min, lon_res, 0, lat_max, 0, -lat_res]  # 仿射变换参数
img_warp(pm25, 'I:\\ObjectRS\\NC2TIFF\\Data\\CHAP_SO2_Y1K_2022_V2(1km).tiff', transform, out_res=out_res, nodata=65535)


